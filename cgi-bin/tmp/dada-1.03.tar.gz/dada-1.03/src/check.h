/* check.c  acb  21-9-1994
 * routines for checking RTNs for undefined and unuse symbols.
 */

#ifndef __CHECK_C
#define __CHECK_C

void check_rtn(pRule rules);

#endif
