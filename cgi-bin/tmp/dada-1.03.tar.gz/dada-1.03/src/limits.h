/* limits.h    Limits for aspects of the pb language.
 * Author:     Andrew C. Bulhak
 * Commenced:  Mon Jul 17 00:48:49 1995
 */

#ifndef __LIMITS_H
#define __LIMITS_H

/* Maximum number of options to be selected from in a single choice */

#define MAX_OPTIONS 256

#endif
