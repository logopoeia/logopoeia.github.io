/* resolve.h  acb  10-9-1994 */

#ifndef __RESOLVE_H
#define __RESOLVE_H

char *resolve_rule(pRule rules, pRule rule);

#endif
