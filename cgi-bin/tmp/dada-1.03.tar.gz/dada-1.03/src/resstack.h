/* resstack.h
 * Author:     Andrew C. Bulhak
 * Commenced:  Mon Jul 17 02:18:11 1995
 */

#ifndef __RESSTACK_H
#define __RESSTACK_H

void resstack_push_new();

void resstack_pop();

#endif
