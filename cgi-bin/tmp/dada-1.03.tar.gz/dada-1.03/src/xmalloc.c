#include <stdlib.h>

void *xmalloc(int size)
{
return malloc(size);
}

